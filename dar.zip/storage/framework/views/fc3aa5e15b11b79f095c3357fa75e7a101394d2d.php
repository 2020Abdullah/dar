<!-- ======= Header ======= -->
<header id="header" class="header fixed-top">
    <div class="d-flex justify-content-center">
        <a href="<?php echo e(route('index')); ?>" class="logo">
        <span class="logo-text">الجمعية المصرية للدفاع الإجتماعي فرع القاهرة مؤسسة الفتيات القاصرات</span>
        </a>
        <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->
</header><!-- End Header -->
<?php /**PATH F:\Laravel_projects\dar\resources\views/components/header.blade.php ENDPATH**/ ?>