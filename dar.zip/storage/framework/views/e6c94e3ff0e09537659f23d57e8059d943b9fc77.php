<?php $__env->startSection('title'); ?>
سجل القيد العام
<?php $__env->stopSection(); ?>

<?php $__env->startSection('Header'); ?>

<?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('SideBar'); ?>

<?php if (isset($component)) { $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Sidebar::class, []); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa)): ?>
<?php $component = $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa; ?>
<?php unset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<main id="main" class="main">
    <div class="export">
        <button id="print" class="btn btn-success"><i class="fa-solid fa-print"></i> طباعة</button>
    </div>
    <div id="personal">
        <h2>بيانات الحالة</h2>
        <hr/>
            <section class="section report">
                <div class="d-flex report-header">
                    <?php if(isset($student->pic)): ?>
                        <img src="<?php echo e(asset('public/Image/'. $student->pic)); ?>" class="card-img-top" alt="...">
                    <?php endif; ?>
                </div>
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>الإسم</h4>
                            <p class="lead"><?php echo e($student->Name); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>كود البنت</h4>
                            <p class="lead"><?php echo e($student->code); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>الرقم القومي</h4>
                            <p class="lead"><?php echo e($student->National_ID); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>رقم القضية</h4>
                            <p class="lead"><?php echo e($student->CaseNumber); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>تاريخ الميلاد</h4>
                            <p class="lead"><?php echo e($student->Birdth); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>العمر</h4>
                            <p class="lead"><?php echo e($student->Age); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>اسم الأم</h4>
                            <p class="lead">
                                <?php if($student->motherName == null): ?>
                                    غير معروف
                                <?php else: ?>
                                    <?php echo e($student->motherName); ?>

                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>ولي الأمر</h4>
                            <p class="lead"><?php echo e($student->NameFather); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>عنوان ولي الأمر</h4>
                            <p class="lead"><?php echo e($student->Address); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>تاريخ الإيداع</h4>
                            <p class="lead"><?php echo e($student->CaseHistory); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>الحالة النفسية</h4>
                            <p class="lead"><?php echo e($student->state); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>نتيجة الإختبار النفسي</h4>
                            <p class="lead"><?php echo e($student->stateResult); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>الحالة العلمية</h4>
                            <p class="lead"><?php echo e($student->stateEducation); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>الإخصائي الإجتماعي</h4>
                            <p class="lead"><?php echo e($student->worker); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>المراقب الإجتماعي</h4>
                            <p class="lead"><?php echo e($student->social_watcher); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>الإتهام</h4>
                            <p class="lead"><?php echo e($student->Accusation); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>طريقة التحويل</h4>
                            <p class="lead"><?php echo e($student->Transfer); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>حالة الأسرة الإقتصادية</h4>
                            <p class="lead"><?php echo e($student->stateFamily); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>المهن السابقة</h4>
                            <p class="lead"><?php echo e($student->Business); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>عدد الإخوة</h4>
                            <p class="lead"><?php echo e($student->Brothers); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>وظيفة الأب</h4>
                            <p class="lead"><?php echo e($student->fatherJop); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>وظيفة الأم</h4>
                            <p class="lead"><?php echo e($student->motherJop); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-box">
                            <h4>ملاحظات</h4>
                            <p class="lead">
                                <?php if($student->Nots == null): ?>
                                    لا يوجد
                                <?php else: ?>
                                    <?php echo e($student->Nots); ?>

                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                </div>
            </section>
    </div>

    </main><!-- End #main -->



<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
  <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel_projects\Dar\resources\views/show.blade.php ENDPATH**/ ?>