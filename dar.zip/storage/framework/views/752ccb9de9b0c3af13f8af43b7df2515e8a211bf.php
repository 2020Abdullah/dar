<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.rtl.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/all.min.css')); ?>">
</head>
<body>
    <?php echo $__env->yieldContent('Header'); ?>
    <?php echo $__env->yieldContent('SideBar'); ?>
    <?php echo $__env->yieldContent('main'); ?>
    <?php echo $__env->yieldContent('footer'); ?>
    <script src="<?php echo e(asset('assets/js/jquery-3.5.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    <?php echo $__env->yieldContent('js'); ?>
</body>
</html>
<?php /**PATH F:\Laravel_projects\dar\resources\views/layouts/master.blade.php ENDPATH**/ ?>