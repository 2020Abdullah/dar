<?php $__env->startSection('title'); ?>
بيانات الحالة
<?php $__env->stopSection(); ?>

<?php $__env->startSection('Header'); ?>

<?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('SideBar'); ?>

<?php if (isset($component)) { $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Sidebar::class, []); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa)): ?>
<?php $component = $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa; ?>
<?php unset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
<main id="main" class="main">
    <div class="export">
        <button id="print" class="btn btn-success"><i class="fa-solid fa-print"></i> طباعة</button>
    </div>
    <div id="personal">
        <h2 class="table-title">بيانات الحالة</h2>
            <section class="section report">
                <table class="table table-bordered table-show">
                    <?php if(isset($student->pic)): ?>
                        <tr>
                            <td colspan="4">
                                <img src="<?php echo e(asset('public/Image/'. $student->pic)); ?>" class="card-img-top" alt="...">
                            </td>
                        </tr>
                    <?php endif; ?>
                    <tr>
                        <td>الإسم</td>
                        <td><?php echo e($student->Name); ?></td>
                        <td>الكود</td>
                        <td><?php echo e($student->code); ?></td>
                    </tr>
                    <tr>
                        <td>الرقم القومي</td>
                        <td>
                            <?php if($student->National_ID == null): ?>
                                غير معروف
                            <?php else: ?>
                                <?php echo e($student->National_ID); ?>

                            <?php endif; ?>
                        </td>
                        <td>رقم القضية</td>
                        <td><?php echo e($student->CaseNumber); ?></td>
                    </tr>
                    <tr>
                        <td>تاريخ الميلاد</td>
                        <td><?php echo e($student->Birdth); ?></td>
                        <td>العمر</td>
                        <td><?php echo e($student->Age); ?></td>
                    </tr>
                    <tr>
                        <td>اسم الأم</td>
                        <td>
                            <?php if($student->motherName == null): ?>
                                غير معروف
                            <?php else: ?>
                                <?php echo e($student->motherName); ?>

                            <?php endif; ?>
                        </td>
                        <td>ولي الأمر</td>
                        <td><?php echo e($student->NameFather); ?></td>
                    </tr>
                    <tr>
                        <td>عنوان ولي الأمر</td>
                        <td><?php echo e($student->Address); ?></td>
                        <td>تاريخ الإيداع</td>
                        <td><?php echo e($student->CaseHistory); ?></td>
                    </tr>
                    <tr>
                        <td>الحالة النفسية</td>
                        <td><?php echo e($student->state); ?></td>
                        <td>الحالة العلمية</td>
                        <td><?php echo e($student->stateEducation); ?></td>
                    </tr>
                    <tr>
                        <td>نتيجة الإختبار النفسي</td>
                        <td><?php echo e($student->stateResult); ?></td>
                        <td>الإتهام</td>
                        <td><?php echo e($student->Accusation); ?></td>
                    </tr>
                    <tr>
                        <td>الإخصائي الإجتماعي</td>
                        <td><?php echo e($student->worker); ?></td>
                        <td>المراقب الإجتماعي</td>
                        <td><?php echo e($student->social_watcher); ?></td>
                    </tr>
                    <tr>
                        <td>الإتهام</td>
                        <td><?php echo e($student->Accusation); ?></td>
                        <td>طريقة التحويل</td>
                        <td><?php echo e($student->Transfer); ?></td>
                    </tr>
                    <tr>
                        <td>حالة الأسرة الإقتصادية</td>
                        <td><?php echo e($student->stateFamily); ?></td>
                        <td>المهن السابقة</td>
                        <td><?php echo e($student->Business); ?></td>
                    </tr>
                    <tr>
                        <td>وظيفة الأب</td>
                        <td><?php echo e($student->fatherJop); ?></td>
                        <td>وظيفة الأم</td>
                        <td><?php echo e($student->motherJop); ?></td>
                    </tr>
                    <tr>
                        <td>عدد الإخوة</td>
                        <td><?php echo e($student->Brothers); ?></td>
                        <td>ملاحظات</td>
                        <td>
                            <?php if($student->Nots == null): ?>
                                لا يوجد
                            <?php else: ?>
                                <?php echo e($student->Nots); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </section>
    </div>

    </main><!-- End #main -->



<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
  <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel_projects\dar\resources\views/show.blade.php ENDPATH**/ ?>