<?php $__env->startSection('title'); ?>
لوحة التحكم
<?php $__env->stopSection(); ?>

<?php $__env->startSection('Header'); ?>

<?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('SideBar'); ?>

<?php if (isset($component)) { $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Sidebar::class, []); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa)): ?>
<?php $component = $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa; ?>
<?php unset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <main id="main" class="main">
        <h2>بيانات الحالة</h2>
        <hr/>
        <section class="section report">
            <div class="row">
                <div class="col-md-3 mb-3">
                    <div class="card-box">
                        <h3>الإسم</h3>
                        <p class="lead"><?php echo e($student->Name); ?></p>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card-box">
                        <h3>الكود</h3>
                        <p class="lead"><?php echo e($student->code); ?></p>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card-box">
                        <h3>الإتهام</h3>
                        <p class="lead"><?php echo e($student->Accusation); ?></p>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card-box">
                        <h3>الإخصائي الإجتماعي</h3>
                        <p class="lead"><?php echo e($student->worker); ?></p>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card-box">
                        <h3>تاريخ الهروب</h3>
                        <p class="lead"><?php echo e($student->date_escape); ?></p>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card-box">
                        <h3>كيفية الهروب</h3>
                        <p class="lead"><?php echo e($student->how_escape); ?></p>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card-box">
                        <h3>تاريخ العودة</h3>
                        <p class="lead"><?php echo e($student->date_back); ?></p>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card-box">
                        <h3>كيفية العودة</h3>
                        <p class="lead"><?php echo e($student->how_back); ?></p>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card-box">
                        <h3>عدد مرات الهروب</h3>
                        <p class="lead"><?php echo e($student->number_back); ?></p>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card-box">
                        <h3>العودة وسببها</h3>
                        <p class="lead"><?php echo e($student->reason_back); ?></p>
                    </div>
                </div>
            </div>
        </section>

    </main><!-- End #main -->



<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel_projects\Dar\resources\views/ecape/show.blade.php ENDPATH**/ ?>