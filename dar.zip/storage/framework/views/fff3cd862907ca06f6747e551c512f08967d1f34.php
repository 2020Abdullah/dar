<footer class="footer footer-static footer-light navbar-shadow">
    <div class="myInfo">
        <div class="image">
            <img src="<?php echo e(asset('img/myLogo.png')); ?>" alt="img"/>
        </div>
        <div class="text">
            <span>تصميم وبرمجة </span>
            <a class="link" href="https://www.facebook.com/FRABDALLA/" target="_blank">المهندس عبد الله محمد </a><br/>
            <span>لطلب برامج التصميم والبرمجة من المهندس</span><br/>
            <span>01095314681 - 01503317732</span>
        </div>
    </div>
</footer>
<?php /**PATH F:\Laravel_projects\Dar\resources\views/components/footer.blade.php ENDPATH**/ ?>