<?php $__env->startSection('title'); ?>
تعديل بيانات الحالة
<?php $__env->stopSection(); ?>

<?php $__env->startSection('Header'); ?>

<?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('SideBar'); ?>

<?php if (isset($component)) { $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Sidebar::class, []); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa)): ?>
<?php $component = $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa; ?>
<?php unset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <main id="main" class="main">
        <h2>تعديل بيانات الحالة</h2>
        <hr/>
        <?php echo $__env->make('layouts.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section class="section edit-report">
            <form action="<?php echo e(url('update')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" value="<?php echo e($student->id); ?>" name="id"/>
                <div class="row">
                    <div class="col-md-3 mb-3">
                    <label class="form-label d-block text-start">الكود</label>
                    <input type="text" value="<?php echo e($student->code); ?>" class="form-control" name="code" />
                    </div>
                    <div class="col-md-3 mb-3">
                    <label class="form-label d-block text-start">الإسم</label>
                    <input type="text" value="<?php echo e($student->Name); ?>" class="form-control" name="Name"/>
                    </div>
                    <div class="col-md-3 mb-3">
                    <label class="form-label d-block text-start">الرقم القومي</label>
                    <input type="text" value="<?php echo e($student->National_ID); ?>" class="form-control" name="National_ID"/>
                    </div>
                    <div class="col-md-3 mb-3">
                    <label class="form-label d-block text-start">تاريخ الإيداع</label>
                    <input type="date" value="<?php echo e($student->CaseHistory); ?>" class="form-control" name="CaseHistory"/>
                    </div>
                    <div class="col-md-3 mb-3">
                    <label class="form-label d-block text-start">رقم القضية</label>
                    <input type="text" value="<?php echo e($student->CaseNumber); ?>" class="form-control" name="CaseNumber"/>
                    </div>
                    <div class="col-md-3 mb-3">
                    <label class="form-label d-block text-start">اسم الأم</label>
                    <input type="text" value="<?php echo e($student->motherName); ?>" class="form-control" name="motherName"/>
                    </div>
                    <div class="col-md-3 mb-3">
                    <label class="form-label d-block text-start">ولي الأمر</label>
                    <input type="text" value="<?php echo e($student->NameFather); ?>" class="form-control" name="NameFather"/>
                    </div>
                    <div class="col-md-3 mb-3">
                    <label class="form-label d-block text-start">عنوان ولي الأمر</label>
                    <input type="text" value="<?php echo e($student->Address); ?>" class="form-control" name="Address"/>
                    </div>
                    <div class="col-md-3 mb-3">
                    <label class="form-label d-block text-start">الحالة العلمية</label>
                    <input type="text" value="<?php echo e($student->stateEducation); ?>" class="form-control" name="stateEducation"/>
                    </div>
                    <div class="col-md-3 mb-3">
                    <label class="form-label d-block text-start">الإتهام</label>
                    <input type="text" value="<?php echo e($student->Accusation); ?>" class="form-control" name="Accusation"/>
                    </div>
                    <div class="col-md-3 mb-3">
                    <label class="form-label d-block text-start">طريقة التحويل</label>
                    <input type="text" value="<?php echo e($student->Transfer); ?>" class="form-control" name="Transfer"/>
                    </div>
                    <div class="col-md-3 mb-3">
                    <label class="form-label d-block text-start">الحالة النفسية</label>
                    <input type="text" value="<?php echo e($student->state); ?>" class="form-control" name="state"/>
                    </div>
                    <div class="col-md-3 mb-3">
                    <label class="form-label d-block text-start">نتيجة الإختبار النفسي</label>
                    <input type="text" value="<?php echo e($student->stateResult); ?>" class="form-control" name="stateResult"/>
                    </div>
                    <div class="col-md-3 mb-3">
                    <label class="form-label d-block text-start">حالة الأسرة الإقتصادية</label>
                    <input type="text" value="<?php echo e($student->stateFamily); ?>" class="form-control" name="stateFamily"/>
                    </div>
                    <div class="col-md-3 mb-3">
                    <label class="form-label d-block text-start"> المهن السابقة</label>
                    <input type="text" value="<?php echo e($student->Business); ?>" class="form-control" name="Business"/>
                    </div>
                    <div class="col-md-3 mb-3">
                    <label class="form-label d-block text-start"> عدد الإخوة</label>
                    <input type="text" value="<?php echo e($student->Brothers); ?>" class="form-control" name="Brothers"/>
                    </div>
                    <div class="col-md-3 mb-3">
                    <label class="form-label d-block text-start">وظيفة الأب</label>
                    <input type="text" value="<?php echo e($student->fatherJop); ?>" class="form-control" name="fatherJop"/>
                    </div>
                    <div class="col-md-3 mb-3">
                    <label class="form-label d-block text-start">وظيفة الأم</label>
                    <input type="text" value="<?php echo e($student->motherJop); ?>" class="form-control" name="motherJop"/>
                    </div>
                    <div class="col-md-3 mb-3">
                    <label class="form-label d-block text-start">المراقب الإجتماعي</label>
                    <input type="text" value="<?php echo e($student->social_watcher); ?>" class="form-control" name="social_watcher"/>
                    </div>
                    <div class="col-md-3 mb-3">
                    <label class="form-label d-block text-start">الإخصائي الإجتماعي</label>
                    <input type="text" value="<?php echo e($student->worker); ?>" class="form-control" name="worker"/>
                    </div>
                    <div class="col-md-12 mb-3">
                    <label class="form-label d-block text-start">صورة البنت</label>
                    <input type="file" name="Image" class="form-control" id="Image" multiple/>
                    </div>
                    <div class="col-md-12 mb-3">
                    <label class="form-label d-block text-start">ملاحظات أخرى</label>
                    <textarea class="form-control" name="Nots"><?php echo e($student->Nots); ?></textarea>
                    </div>
                </div>
                <input type="submit" class="btn btn-success" value="حفظ وتعديل"/>
            </form>
        </section>

    </main><!-- End #main -->



<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel_projects\dar\resources\views/edit.blade.php ENDPATH**/ ?>