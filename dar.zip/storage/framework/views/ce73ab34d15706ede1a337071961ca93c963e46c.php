<?php $__env->startSection('title'); ?>
لوحة التحكم
<?php $__env->stopSection(); ?>

<?php $__env->startSection('Header'); ?>

<?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('SideBar'); ?>

<?php if (isset($component)) { $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Sidebar::class, []); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa)): ?>
<?php $component = $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa; ?>
<?php unset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <main id="main" class="main">
        <h2>تعديل بيانات الحالة</h2>
        <hr/>
        <?php echo $__env->make('layouts.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section class="section edit-report">
            <form action="<?php echo e(route('index-escape.update', '')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" value="<?php echo e($student->student_id); ?>" name="student_id"/>
                <div class="row">
                    <div class="col-md-4 mb-3">
                    <label class="form-label d-block text-start">الكود</label>
                    <input type="text" value="<?php echo e($student->code); ?>" class="form-control" name="code" readonly/>
                    </div>
                    <div class="col-md-4 mb-3">
                    <label class="form-label d-block text-start">الإسم</label>
                    <input type="text" value="<?php echo e($student->Name); ?>" class="form-control" name="Name" readonly/>
                    </div>
                    <div class="col-md-4 mb-3">
                    <label class="form-label d-block text-start">تاريخ الإيداع</label>
                    <input type="date" value="<?php echo e($student->CaseHistory); ?>" class="form-control" name="CaseHistory" readonly/>
                    </div>
                    <div class="col-md-4 mb-3">
                    <label class="form-label d-block text-start">تاريخ الهروب</label>
                    <input type="date" value="<?php echo e($student->date_escape); ?>" class="form-control" name="date_escape"/>
                    </div>
                    <div class="col-md-4 mb-3">
                    <label class="form-label d-block text-start">كيفية الهروب</label>
                    <input type="text" value="<?php echo e($student->how_escape); ?>" class="form-control" name="how_escape"/>
                    </div>
                    <div class="col-md-4 mb-3">
                    <label class="form-label d-block text-start">تاريخ العودة</label>
                    <input type="date" value="<?php echo e($student->date_back); ?>" class="form-control" name="date_back"/>
                    </div>
                    <div class="col-md-4 mb-3">
                    <label class="form-label d-block text-start">كيفية العودة</label>
                    <input type="text" value="<?php echo e($student->how_back); ?>" class="form-control" name="how_back"/>
                    </div>
                    <div class="col-md-4 mb-3">
                    <label class="form-label d-block text-start">عدد مرات الهروب</label>
                    <input type="text" value="<?php echo e($student->number_back); ?>" class="form-control" name="number_back"/>
                    </div>
                    <div class="col-md-4 mb-3">
                    <label class="form-label d-block text-start">العودة وسببها</label>
                    <input type="text" value="<?php echo e($student->reason_back); ?>" class="form-control" name="reason_back"/>
                    </div>
                </div>
                <input type="submit" class="btn btn-success" value="حفظ وتعديل"/>
            </form>
        </section>

    </main><!-- End #main -->



<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel_projects\Dar\resources\views/ecape/edit.blade.php ENDPATH**/ ?>