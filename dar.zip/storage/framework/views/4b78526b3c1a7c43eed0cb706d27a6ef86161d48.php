<?php $__env->startSection('title'); ?>
إضافة بيانات جديدة
<?php $__env->stopSection(); ?>

<?php $__env->startSection('Header'); ?>

<?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('SideBar'); ?>

<?php if (isset($component)) { $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Sidebar::class, []); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa)): ?>
<?php $component = $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa; ?>
<?php unset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <main id="main" class="main">
        <h2 class="text-start">إضافة بيانات الهروب والعودة</h2>
        <hr/>
        <?php echo $__env->make('layouts.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="form-data">
            <form action="<?php echo e(route('index-escape.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <fieldset class="border p-2" id="student_info">
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <div class="form-field">
                                <label for="nametxt" class="form-label">الإسم</label>
                                <select name="st_Name" class="form-control">
                                    <option>...</option>
                                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($student->id); ?>"><?php echo e($student->Name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <div class="form-field">
                                <label for="date_escape	" class="form-label">تاريخ الهروب</label>
                                <input type="date" name="date_escape" class="form-control" id="date_escape">
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <div class="form-field">
                                <label for="how_escape	" class="form-label">كيفية الهروب</label>
                                <input type="text" name="how_escape" class="form-control" id="date_escape">
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <div class="form-field">
                                <label for="date_back" class="form-label">تاريخ العودة</label>
                                <input type="date" name="date_back" class="form-control" id="date_escape">
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <div class="form-field">
                                <label for="how_back" class="form-label">كيفية العودة</label>
                                <input type="text" name="how_back" class="form-control" id="date_escape">
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <div class="form-field">
                                <label for="number_back" class="form-label">عدد مرات الهروب</label>
                                <input type="number" name="number_back" class="form-control" id="date_escape">
                            </div>
                        </div>
                        <div class="col-md-4 mb-3">
                            <div class="form-field">
                                <label for="reason_back" class="form-label">العودة وسببها</label>
                                <input type="text" name="reason_back" class="form-control" id="date_escape">
                            </div>
                        </div>
                    </div>
                </fieldset>
                <div class="mt-3">
                    <input type="submit" class="btn btn-success" value="حفظ البيانات"/>
                </div>
            </form>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel_projects\dar\resources\views/ecape/Add.blade.php ENDPATH**/ ?>