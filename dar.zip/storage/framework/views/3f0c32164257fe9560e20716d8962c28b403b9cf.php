<?php $__env->startSection('title'); ?>
سجل الهروب والعودة
<?php $__env->stopSection(); ?>

<?php $__env->startSection('Header'); ?>

<?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('SideBar'); ?>

<?php if (isset($component)) { $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Sidebar::class, []); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa)): ?>
<?php $component = $__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa; ?>
<?php unset($__componentOriginalee6f77ea8284c9edd154cd0c9b3b80eff04c2bfa); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <main id="main" class="main">
        <h2>سجل الهروب والعودة</h2>
        <hr/>
        <?php echo $__env->make('layouts.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section class="section dashboard">
            <form action="<?php echo e(route('index-escape.Search')); ?>" method="POST" class="d-flex mb-3">
                <?php echo csrf_field(); ?>
                <input class="form-control me-2" type="search" placeholder="ادخل الإسم أو الكود ..." aria-label="Search" name="q">
                <button class="btn btn-success" type="submit">بحث </button>
            </form>
            <table class="table table-bordered table-responsive">
                <tr>
                    <th>مسلسل</th>
                    <th>الكود</th>
                    <th>الإسم</th>
                    <th>الإتهام</th>
                    <th>تاريخ الهروب</th>
                    <th>عدد مرات الهروب</th>
                    <th>إجراء</th>
                </tr>
                <?php $__empty_1 = true; $__currentLoopData = $Escape; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $esc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($esc->code); ?></td>
                        <td><a href="<?php echo e(route('index-escape.show', $esc->student_id)); ?>"><?php echo e($esc->Name); ?></a></td>
                        <td><?php echo e($esc->Accusation); ?></td>
                        <td><?php echo e($esc->date_escape); ?></td>
                        <td><?php echo e($esc->number_back); ?></td>
                        <td>
                            <a href="<?php echo e(route('index-escape.edit', $esc->student_id)); ?>" class="btn btn-success"><i class="fa fa-edit"></i> تعديل</a>
                            <button type="button" class="btn btn-danger delete" data-bs-toggle="modal" data-bs-target="#del<?php echo e($esc->code); ?>" id="<?php echo e($esc->code); ?>">
                                <i class="fa fa-trash"></i> حذف
                            </button>
                        <!-- Modal-Delete -->
                        <div class="modal fade" id="del<?php echo e($esc->code); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                <h5 class="modal-title text-danger" id="exampleModalLabel">تأكيد حذف الحالة </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form action="<?php echo e(route('index-escape.destroy', '')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" value="<?php echo e($esc->code); ?>" name="code"/>
                                        <input type="hidden" value="<?php echo e($esc->id); ?>" name="id"/>
                                        <div class="mb-3 text-start">
                                            <label class="form-label">هل تريد حذف هذه الحالة بالفعل ؟</label>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                                            <input type="submit" value="تأكيد" class="btn btn-success"/>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8">لا توجد بيانات</td>
                    </tr>
                <?php endif; ?>
            </table>
        </section>
        <?php echo e($Escape->links()); ?>

    </main><!-- End #main -->



<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
    <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel_projects\dar\resources\views/ecape/index.blade.php ENDPATH**/ ?>