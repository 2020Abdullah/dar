<!DOCTYPE html>
<html lang="ar" dir="rtl">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>بيانات الحالة</title>
<body>
    <style>
        .row {
            display: grid;
            grid-template-columns: 200px repeat(auto-fill, 100px) 300px;
        }
    </style>
    <h2>بيانات الحالة</h2>
    <hr/>
    <section class="section report">
        <div class="d-flex report-header">
            <?php if(isset($student->pic)): ?>
                <img src="<?php echo e(asset('public/Image/'. $student->pic)); ?>" class="card-img-top" alt="...">
            <?php endif; ?>
        </div>
        <div class="row">
            <div class="col">
                <h3 class="form-label d-block text-start">الإسم</h3>
                <p><?php echo e($student->Name); ?></p>
            </div>
            <div class="col">
                <h3 class="form-label d-block text-start">كود البنت</h3>
                <p><?php echo e($student->code); ?></p>
            </div>
            <div class="col">
                <h3 class="form-label d-block text-start">الرقم القومي</h3>
                <p><?php echo e($student->National_ID); ?></p>
            </div>
            <div class="col">
                <h3 class="form-label d-block text-start">رقم القضية</h3>
                <p><?php echo e($student->CaseNumber); ?></p>
            </div>
            <div class="col">
                <h3 class="form-label d-block text-start">تاريخ الميلاد</h3>
                <p><?php echo e($student->Birdth); ?></p>
            </div>
            <div class="col">
                <h3 class="form-label d-block text-start">العمر</h3>
                <p><?php echo e($student->Age); ?></p>
            </div>
            <div class="col">
                <h3 class="form-label d-block text-start">تاريخ الميلاد</h3>
                <p><?php echo e($student->Birdth); ?></p>
            </div>
            <div class="col">
                <h3 class="form-label d-block text-start">ولي الأمر</h3>
                <p><?php echo e($student->NameFather); ?></p>
            </div>
            <div class="col">
                <h3 class="form-label d-block text-start">عنوان ولي الأمر</h3>
                <p><?php echo e($student->Address); ?></p>
            </div>
            <div class="col">
                <h3 class="form-label d-block text-start">تاريخ الإيداع</h3>
                <p><?php echo e($student->CaseHistory); ?></p>
            </div>
            <div class="col">
                <h3 class="form-label d-block text-start">الحالة النفسية</h3>
                <p><?php echo e($student->state); ?></p>
            </div>
            <div class="col">
                <h3 class="form-label d-block text-start">نتيجة الإختبار النفسية</h3>
                <p><?php echo e($student->stateResult); ?></p>
            </div>
            <div class="col">
                <h3 class="form-label d-block text-start">الحالة العلمية</h3>
                <p><?php echo e($student->stateEducation); ?></p>
            </div>
            <div class="col">
                <h3 class="form-label d-block text-start">الإخصائي الإجتماعي</h3>
                <p><?php echo e($student->worker); ?></p>
            </div>
            <div class="col">
                <h3 class="form-label d-block text-start">المراقب الإجتماعي</h3>
                <p><?php echo e($student->social_watcher); ?></p>
            </div>
            <div class="col">
                <h3 class="form-label d-block text-start">الإتهام</h3>
                <p><?php echo e($student->Accusation); ?></p>
            </div>
            <div class="col">
                <h3 class="form-label d-block text-start">طريقة التحويل</h3>
                <p><?php echo e($student->Transfer); ?></p>
            </div>
            <div class="col">
                <h3 class="form-label d-block text-start">حالة الأسرة الإقتصادية</h3>
                <p><?php echo e($student->stateFamily); ?></p>
            </div>
            <div class="col">
                <h3 class="form-label d-block text-start">عدد الإخوة</h3>
                <p><?php echo e($student->Brothers); ?></p>
            </div>
            <div class="col">
                <h3 class="form-label d-block text-start">ملاحظات</h3>
                <p><?php echo e($student->Nots); ?></p>
            </div>
        </div>
    </section>

</body>
</html>


<?php /**PATH F:\Laravel_projects\Dar\resources\views/pdf/personal.blade.php ENDPATH**/ ?>